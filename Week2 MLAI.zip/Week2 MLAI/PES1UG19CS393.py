"""
You can create any other helper funtions.
Do not modify the given functions
"""
import heapq

def A_star_Traversal(cost, heuristic, start_point, goals):
    """
    Perform A* Traversal and find the optimal path
    Args:
        cost: cost matrix (list of floats/int)
        heuristic: heuristics for A* (list of floats/int)
        start_point: Staring node (int)
        goals: Goal states (list of ints)
    Returns:
        path: path to goal state obtained from A*(list of ints)
    """

    if not cost or start_point>=len(cost):           #Handles empty graph edge case and start out of bounds
        return []

    if start_point in goals:    #Handles start is goal edge case
        return [start_point]

    explored=[0 for i in range(len(cost))]
    waitList=[(heuristic[start_point],start_point)]
    heapq.heapify(waitList)             #Use heap to implement a priorty queue

    waitNodes=[0 for i in range(len(cost))]     #for quick lookup of nodes in queue
    waitNodes[start_point]=1
    parents=[start_point for i in range(len(cost))]

    while(waitList):
        q = heapq.heappop(waitList)
        #print(q)
        waitNodes[q[1]]=0
        explored[q[1]]=1        #add node to explored list

        if q[1] in goals:
            #print("Goal {} Found!, distance: {}".format(q[1],q[0]-heuristic[q[1]]))
            #print(waitList)
            path=[q[1]]

            cur = parents[q[1]]
            while (cur != start_point):
                path.append(cur)
                cur = parents[cur]
            path.append(cur)
            #print("Path to {} is {}".format(q[1], path[::-1]))
            return path[::-1]

        k=0
        prevcost=q[0]-heuristic[q[1]]
        for i in cost[q[1]]:
            if i>0 and not explored[k]:         #find adjacent unexplored vertices
                if waitNodes[k]:                #if adj vertex already waiting, update its f cost(if new cost lesser)
                    for j in range(len(waitList)):
                        if waitList[j][1]==k:
                            minv=min(waitList[j][0],prevcost+heuristic[k]+cost[q[1]][k])
                            if minv!=waitList[j][0]:
                                parents[k]=q[1]
                            heapq.heappush(waitList,(minv, waitList[j][1]))
                            waitList.remove(waitList[j])
                            break

                else:                       #else add it to wait list
                    heapq.heappush(waitList,(prevcost+heuristic[k]+cost[q[1]][k],k))
                    waitNodes[k]=1
                    parents[k]=q[1]
            k+=1

    return [] #no soln case


def DFS_Traversal(cost, start_point, goals):
    """
    Perform DFS Traversal and find the optimal path
        cost: cost matrix (list of floats/int)
        start_point: Staring node (int)
        goals: Goal states (list of ints)
    Returns:
        path: path to goal state obtained from DFS(list of ints)
    """
    if not cost or start_point>=len(cost):      #Handles empty graph edge case and start out of bounds
        return []
    if start_point in goals:                    #Handles start is goal case
        return [start_point]

    visited=[0 for i in range(len(cost))]
    n=len(cost)
    stack=[start_point]
    visited[start_point]=1
    while(stack):
        cur=stack[-1]
        flag=False
        for i in range(1,n):
            if cost[cur][i]>0 and not visited[i]:
                stack.append(i)
                visited[i]=1
                flag=True           #signifies not a deadend
                break
        if not flag:
            # stack=stack[:-1]
            stack.pop()             #backtrack
        else:
            if stack[-1] in goals:
                path=stack
                #print(path)
                return path
    return []   #no soln case


