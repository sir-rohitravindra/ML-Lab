"""
You can create any other helper funtions.
Do not modify the given functions
"""
import heapq
#
#
# def A_star_Traversalcopy(cost, heuristic, start_point, goals):
#     """
#     Perform A* Traversal and find the optimal path
#     Args:
#         cost: cost matrix (list of floats/int)
#         heuristic: heuristics for A* (list of floats/int)
#         start_point: Staring node (int)
#         goals: Goal states (list of ints)
#     Returns:
#         path: path to goal state obtained from A*(list of ints)
#     """
#
#     # TODO
#     if start_point in goals:
#         return [start_point]
#     explored=list()
#     waitList=[(heuristic[start_point],start_point)]
#     waitNodes=[start_point]
#     parents=[start_point for i in range(len(cost))]
#     while(waitList!=[]):
#         q=min(waitList)
#         waitList.remove(q)
#         explored.append(q[1])
#         if q[1] in goals:
#             #print("Goal {} Found!, distance: {}".format(q[1],q[0]-heuristic[q[1]]))
#             path=[q[1]]
#             #path.append(q[1])
#             g=q[1]
#             cur = parents[g]
#             while (cur != start_point):
#                 path.append(cur)
#                 cur = parents[cur]
#             path.append(cur)
#             #print("Path to {} is {}".format(g, path[::-1]))
#             return path[::-1]
#
#         k=0
#         prevcost=q[0]-heuristic[q[1]]
#         for i in cost[q[1]]:
#             if i>0 and k not in explored:
#                 if k in waitNodes:
#                     for j in range(len(waitList)):
#                         if waitList[j][1]==k:
#                             minv=min(waitList[j][0],prevcost+heuristic[k]+cost[q[1]][k])
#                             if minv!=waitList[j][0]:
#                                 parents[k]=q[1]
#                             waitList.append((minv, waitList[j][1]))
#                             waitList.remove(waitList[j])
#
#                 else:
#                     waitList.append((prevcost+heuristic[k]+cost[q[1]][k],k))
#                     waitNodes.append(k)
#                     parents[k]=q[1]
#             k+=1
#     return -1 #no soln case
#     # for g in goals:
#     #     l=[g,]
#     #     cur=parents[g]
#     #     while(cur!=start_point):
#     #         l.append(cur)
#     #         cur=parents[cur]
#     #     l.append(cur)
#     #     print("Path to {} is {}".format(g,l[::-1]))


def A_star_Traversal(cost, heuristic, start_point, goals):
    """
    Perform A* Traversal and find the optimal path
    Args:
        cost: cost matrix (list of floats/int)
        heuristic: heuristics for A* (list of floats/int)
        start_point: Staring node (int)
        goals: Goal states (list of ints)
    Returns:
        path: path to goal state obtained from A*(list of ints)
    """

    # TODO
    if not cost:
        return []

    if start_point in goals:
        return [start_point]
    #explored=list()
    explored=[0 for i in range(len(cost))]
    waitList=[(heuristic[start_point],start_point)]
    heapq.heapify(waitList)

    waitNodes=[0 for i in range(len(cost))]
    waitNodes[start_point]=1
    parents=[start_point for i in range(len(cost))]
    while(waitList):
        #q=min(waitList)
        #waitList.remove(q)
        q = heapq.heappop(waitList)
        waitNodes[q[1]]=0
        #explored.append(q[1])
        explored[q[1]]=1
        if q[1] in goals:
            #print("Goal {} Found!, distance: {}".format(q[1],q[0]-heuristic[q[1]]))
            path=[q[1]]
            #path.append(q[1])

            cur = parents[q[1]]
            while (cur != start_point):
                path.append(cur)
                cur = parents[cur]
            path.append(cur)
            #print("Path to {} is {}".format(q[1], path[::-1]))
            return path[::-1]

        k=0
        prevcost=q[0]-heuristic[q[1]]
        for i in cost[q[1]]:
            if i>0 and not explored[k]:
                if waitNodes[k]:

                    for j in range(len(waitList)):
                        if waitList[j][1]==k:
                            minv=min(waitList[j][0],prevcost+heuristic[k]+cost[q[1]][k])
                            if minv!=waitList[j][0]:
                                parents[k]=q[1]
                            #waitList.append((minv, waitList[j][1]))
                            heapq.heappush(waitList,(minv, waitList[j][1]))
                            waitList.remove(waitList[j])
                            break

                else:
                    # waitList.append((prevcost+heuristic[k]+cost[q[1]][k],k))
                    heapq.heappush(waitList,(prevcost+heuristic[k]+cost[q[1]][k],k))
                    waitNodes[k]=1
                    parents[k]=q[1]
            k+=1
    return [] #no soln case
    # for g in goals:
    #     l=[g,]
    #     cur=parents[g]
    #     while(cur!=start_point):
    #         l.append(cur)
    #         cur=parents[cur]
    #     l.append(cur)
    #     print("Path to {} is {}".format(g,l[::-1]))



def DFS_Traversal(cost, start_point, goals):
    """
    Perform DFS Traversal and find the optimal path 
        cost: cost matrix (list of floats/int)
        start_point: Staring node (int)
        goals: Goal states (list of ints)
    Returns:
        path: path to goal state obtained from DFS(list of ints)
    """
    if not cost:
        return []
    if start_point in goals:
        return [start_point]
    visited=[0 for i in range(len(cost))]
    n=len(cost)
    stack=[start_point]
    visited[start_point]=1
    while(stack):
        cur=stack[-1]
        flag=False
        for i in range(1,n):
            if cost[cur][i]>0 and not visited[i]:
                stack.append(i)
                visited[i]=1
                flag=True
                break
        if(not flag):
            # stack=stack[:-1]
            stack.pop()
        else:
            if stack[-1] in goals:
                #while(stack):
                    # path.append(stack[-1])
                    # stack=stack[:-1]
                #print(stack)
                path=stack
                return path

    return []   #no soln case



# cost = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
#             [0, 0, 5, 9, -1, 6, -1, -1, -1, -1, -1],
#             [0, -1, 0, 3, -1, -1, 9, -1, -1, -1, -1],
#             [0, -1, 2, 0, 1, -1, -1, -1, -1, -1, -1],
#             [0, 6, -1, -1, 0, -1, -1, 5, 7, -1, -1],
#             [0, -1, -1, -1, 2, 0, -1, -1, -1, 2, -1],
#             [0, -1, -1, -1, -1, -1, 0, -1, -1, -1, -1],
#             [0, -1, -1, -1, -1, -1, -1, 0, -1, -1, -1],
#             [0, -1, -1, -1, -1, 2, -1, -1, 0, -1, 8],
#             [0, -1, -1, -1, -1, -1, -1, -1, -1, 0, 7],
#             [0, -1, -1, -1, -1, -1, -1, -1, -1, -1, 0]]
# heuristic = [0, 5, 7, 3, 4, 6, 0, 0, 6, 5, 0]
# start = 1
# goals = [4,10]
#
# print(A_star_Traversal(cost, heuristic, start, goals))
#
# print(A_star_Traversalcopy(cost, heuristic, start, goals))
#
# print(DFS_Traversal(cost,start,goals))
#
#
#
