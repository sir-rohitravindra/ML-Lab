import numpy as np
import math

def getMinkowski(d,p):

    s=0
    for i in d:
        s+=math.fabs(i**p)
    return s**(1.0/(p))

class KNN:
    """
    K Nearest Neighbours model
    Args:
        k_neigh: Number of neighbours to take for prediction
        weighted: Boolean flag to indicate if the nieghbours contribution
                  is weighted as an inverse of the distance measure
        p: Parameter of Minkowski distance
    """

    def __init__(self, k_neigh, weighted=False, p=2):

        self.weighted = weighted
        self.k_neigh = k_neigh
        self.p = p

    def fit(self, data, target):
        """
        Fit the model to the training dataset.
        Args:
            data: M x D Matrix( M data points with D attributes each)(float)
            target: Vector of length M (Target class for all the data points as int)
        Returns:
            The object itself
        """

        self.data = data
        self.target = target.astype(np.int64)

        return self

    def find_distance(self, x):
        """
        Find the Minkowski distance to all the points in the train dataset x
        Args:
            x: N x D Matrix (N inputs with D attributes each)(float)
        Returns:
            Distance between each input to every data point in the train dataset
            (N x M) Matrix (N Number of inputs, M number of samples in the train dataset)(float)
        """
        try:
            # print(x)
            # print(self.data)
            # print(self.target)
            distances=[]
            for i in x:
                #print("Row",i)
                disti=[]
                for j in self.data:
                    #print("SUbs ", j-i)
                    disti.append(getMinkowski(j-i,self.p))
                distances.append(disti)

            return np.array(distances)

        except Exception:
            return np.array([])


    def k_neighbours(self, x):
        """
        Find K nearest neighbours of each point in train dataset x
        Note that the point itself is not to be included in the set of k Nearest Neighbours
        Args:
            x: N x D Matrix( N inputs with D attributes each)(float)
        Returns:
            k nearest neighbours as a list of (neigh_dists, idx_of_neigh)
            neigh_dists -> N x k Matrix(float) - Dist of all input points to its k closest neighbours.
            idx_of_neigh -> N x k Matrix(int) - The (row index in the dataset) of the k closest neighbours of each input

            Note that each row of both neigh_dists and idx_of_neigh must be SORTED in increasing order of distance
        """
        try:
            distances=self.find_distance(x)
            # print(x)
            # print(distances)

            k_neigh=[]
            k_indexs=[]
            for i in distances:
                l=[(i[ind],ind) for ind in range(len(i))]
                l.sort()
                knbri = []
                nbrin = []
                for j in range(self.k_neigh):
                    knbri.append(l[j][0])
                    nbrin.append(l[j][1])
                k_neigh.append(knbri)
                k_indexs.append(nbrin)
            #print(np.array([k_neigh,k_indexs]))
            return(np.array([k_neigh,k_indexs]))

        except Exception:
            return np.array([[],[]])

    def predict(self, x):
        """
        Predict the target value of the inputs.
        Args:
            x: N x D Matrix( N inputs with D attributes each)(float)
        Returns:
            pred: Vector of length N (Predicted target value for each input)(int)
        """
        try:
            knn_dist_indx=self.k_neighbours(x)
            #print("###KNNRES###\n",knn_dist_indx,"\n###")
            predictions=list()
            for point in range(len(knn_dist_indx[0])):
                c_f=dict()
                #print(e)
                for r in range(len(knn_dist_indx[1][point])):
                    #print(self.target[int(r)])
                    cl= -self.target[int(knn_dist_indx[1][point][r])]

                    #print(cl,knn_dist_indx[0][point][r])
                    f=1
                    if self.weighted:
                        f/=max(knn_dist_indx[0][point][r],0.000000001)
                    if cl in c_f:
                        c_f[cl]+=f
                    else:
                        c_f[cl]=f

                #print("##\n",c_f,"##\n")
                counts=list(zip(list(c_f.values()),list(c_f.keys())))

                counts.sort(reverse=True)
                #print(counts)
                predictions.append(-counts[0][1])

            return np.array(predictions)

        except Exception:
            return np.array([])

    def evaluate(self, x, y):
        """
        Evaluate Model on test data using 
            classification: accuracy metric
        Args:
            x: Test data (N x D) matrix(float)
            y: True target of test data(int)
        Returns:
            accuracy : (float.)
        """
        try:
            predictions=self.predict(x)
            total_pred=len(predictions)
            #print(predictions,total_pred)
            correct_pred=0
            for i in range(len(predictions)):
                if predictions[i]==y[i]:
                    correct_pred+=1
            accuracy=100*(correct_pred/total_pred)

            return accuracy

        except Exception:
            return 0