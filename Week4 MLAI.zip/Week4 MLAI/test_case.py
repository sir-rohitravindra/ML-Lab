import numpy as np
import pandas as pd
from PES1UG19CS393 import *

fruits = pd.read_table('fruit_data_with_colors.txt')
#print(fruits)
y = fruits['fruit_label']
X = fruits[['mass', 'width', 'height', 'color_score']]
X = np.array(X)
y = np.array(y)
X_test = np.array([[192, 8.4, 7.3, 0.55],
					[162, 7.5, 7.1, 0.83],
					[342, 9.0, 9.4, 0.75],
					[204, 7.5, 9.2, 0.77],
					[86, 6.2, 4.7, 0.80],
					[80, 5.9, 4.3, 0.77],
					[200, 7.3, 10.5, 0.72],
					[174, 7.3, 10.1, 0.72]])
y_test = np.array([1, 1, 3, 3, 2, 2, 4, 4])

model1 = KNN(k_neigh=3, p=2)
model2 = KNN(k_neigh = 3, p = 1, weighted=True)
model1.fit(X, y)
model2.fit(X, y)
print("Model1")
print("------------------")
print('Predicted fruits: ', model1.predict(X_test))
print('Actual fruits: ', y_test)
print('Accuracy: ', model1.evaluate(X_test, y_test))
print("------------------")
print()
print("Model2")
print("------------------")
print('Predicted fruits: ', model2.predict(X_test))
print('Actual fruits: ', y_test)
print('Accuracy: ', model2.evaluate(X_test, y_test))
print("------------------")

