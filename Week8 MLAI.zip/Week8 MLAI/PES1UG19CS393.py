import numpy as np
import pprint

class HMM:
    """
    HMM model class
    Args:
        A: State transition matrix
        states: list of states
        emissions: list of observations
        B: Emmision probabilites
    """

    def __init__(self, A, states, emissions, pi, B):
        self.A = A
        self.B = B
        self.states = states
        self.emissions = emissions
        self.pi = pi
        self.N = len(states)
        self.M = len(emissions)
        self.make_states_dict()

    def make_states_dict(self):
        """
        Make dictionary mapping between states and indexes
        """
        self.states_dict = dict(zip(self.states, list(range(self.N))))
        self.emissions_dict = dict(
            zip(self.emissions, list(range(self.M))))

    def viterbi_algorithm(self, seq):
        """
        Function implementing the Viterbi algorithm
        Args:
            seq: Observation sequence (list of observations. must be in the emmissions dict)
        Returns:
            nu: Porbability of the hidden state at time t given an obeservation sequence
            hidden_states_sequence: Most likely state sequence 
        """
        backTrack=list()
        dailyProbs=list()
        day1hsProbs=list()
        for hs in self.states:
            encoding_hs=self.states_dict[hs]
            prior=self.pi[encoding_hs]

            encoding_mood=self.emissions_dict[seq[0]]
            emission_mood = self.B[encoding_hs][encoding_mood]
            day1hsProbs.append(prior*emission_mood)
        #print(day1hsProbs)
        dailyProbs.append(day1hsProbs)


        for md in seq[1:]:
            todays_hs_probs=list()
            todays_backtrack=list()
            encoding_mood=self.emissions_dict[md]
            yesterdays_hs_probs=dailyProbs[-1]
            for hs in self.states:
                max_hs_prob=0
                max_hs_prev=-1
                encoding_hs=self.states_dict[hs]
                for prev in range(self.N):
                    trans_prob=self.A[prev][encoding_hs]*yesterdays_hs_probs[prev]
                    conditional=self.B[encoding_hs][encoding_mood]
                    #max_hs_prob=max(max_hs_prob,(trans_prob*conditional))
                    cur_trans_hs=(trans_prob*conditional)
                    if(max_hs_prob<cur_trans_hs):
                        max_hs_prob=cur_trans_hs
                        max_hs_prev=prev
                todays_hs_probs.append(max_hs_prob)
                todays_backtrack.append(max_hs_prev)
            dailyProbs.append(todays_hs_probs)
            backTrack.append(todays_backtrack)

        #print(dailyProbs,backTrack)
        preds=list()
        final_day=dailyProbs[-1]
        backtrack_index=final_day.index(max(final_day))
        preds.append(self.states[backtrack_index])

        for entry in backTrack[::-1]:
            preds.append(self.states[entry[backtrack_index]])
            backtrack_index=entry[backtrack_index]
        #print(backTrack,dailyProbs,backtrack_index)
        #print(preds[::-1])
        return preds[::-1]
