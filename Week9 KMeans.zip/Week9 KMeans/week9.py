import numpy as np


def findDistance(record, centroid):

    dist=0
    for i,j in zip(record,centroid):
        dist+=(i-j)**2
    return dist


class KMeansClustering:
    """
    K-Means Clustering Model

    Args:
        n_clusters: Number of clusters(int)
    """

    def __init__(self, n_clusters, n_init=10, max_iter=1000, delta=0.001):

        self.n_cluster = n_clusters
        self.n_init = n_init
        self.max_iter = max_iter
        self.delta = delta

    def init_centroids(self, data):
        idx = np.random.choice(
            data.shape[0], size=self.n_cluster, replace=False)
        print(idx)
        self.centroids = np.copy(data[idx, :])

    def fit(self, data):
        """
        Fit the model to the training dataset.
        Args:
            data: M x D Matrix(M data points with D attributes each)(numpy float)
        Returns:
            The object itself
        """
        if data.shape[0] < self.n_cluster:
            raise ValueError(
                'Number of clusters is grater than number of datapoints')

        best_centroids = None
        m_score = float('inf')

        for _ in range(self.n_init):
            self.init_centroids(data)

            for _ in range(self.max_iter):
                cluster_assign = self.e_step(data)
                old_centroid = np.copy(self.centroids)
                self.m_step(data, cluster_assign)

                if np.abs(old_centroid - self.centroids).sum() < self.delta:
                    break

            cur_score = self.evaluate(data)

            if cur_score < m_score:
                m_score = cur_score
                best_centroids = np.copy(self.centroids)

        self.centroids = best_centroids

        return self

    def e_step(self, data):
        """
        Expectation Step.
        Finding the cluster assignments of all the points in the data passed
        based on the current centroids
        Args:
            data: M x D Matrix (M training samples with D attributes each)(numpy float)
        Returns:
            Cluster assignment of all the samples in the training data
            (M) Vector (M number of samples in the train dataset)(numpy int)
        """

        assignments=list()
        for record in data:
            closest=float('inf')
            assigned=-1
            for count,centroid in enumerate(self.centroids):
                dist=findDistance(record,centroid)
                if dist<closest:
                    assigned=count
                    closest=dist
            assignments.append(assigned)
        return np.array(assignments)

    def m_step(self, data, cluster_assgn):
        """
        Maximization Step.
        Compute the centroids
        Args:
            data: M x D Matrix(M training samples with D attributes each)(numpy float)
        Change self.centroids
        """
        cluster_counts=dict()
        cluster_means=dict()
        for i in range(len(cluster_assgn)):
            ck=cluster_assgn[i]
            if ck in cluster_means:
                cluster_means[ck]+=data[i]
            else:
                cluster_means[ck]=np.copy(data[i])
            if ck in cluster_counts:
                cluster_counts[ck]+=1
            else:
                cluster_counts[ck]=1
        for i in cluster_means:
            cluster_means[i]/=cluster_counts[i]

        new_centroids=list()
        
        centroids=sorted(list(cluster_means.keys()))
        for i in centroids:
            new_centroids.append(cluster_means[i])
        self.centroids=np.array(new_centroids)

        return



    def evaluate(self, data):
        """
        K-Means Objective
        Args:
            data: Test data (M x D) matrix (numpy float)
        Returns:
            metric : (float.)
        """
        metric=0

        for cent in self.centroids:
            for record in data:
                metric+=findDistance(record,cent)

        #print(metric)
        return metric

