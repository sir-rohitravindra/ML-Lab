'''
Assume df is a pandas dataframe object of the dataset given
'''

import numpy as np
import pandas as pd
import random
from math import log2

def getEntropy(size,x):
    return -(log2(x/size)*(x/size))
'''Calculate the entropy of the enitre dataset'''
# input:pandas_dataframe
# output:int/float
def get_entropy_of_dataset(df):

    #print(df)
    classes=dict(df.iloc[:,-1].value_counts())
    #print(classes,df.shape[0])
    size=df.shape[0]
    entropy=0
    for cl in classes:
        #print(cl,classes[cl],getEntropy(size,classes[cl]))
        entropy+=getEntropy(size,classes[cl])
    #print(entropy)
    return entropy


'''Return avg_info of the attribute provided as parameter'''
# input:pandas_dataframe,str   {i.e the column name ,ex: Temperature in the Play tennis dataset}
# output:int/float
def get_avg_info_of_attribute(df, attribute):

    dfattr=df.loc[:,[attribute,df.columns[-1]]]
    cases=dfattr[attribute].unique()
    #print(cases)
    entropies=[]
    for case in cases:
        dc=dfattr.loc[(dfattr[attribute]==case)]
        #print(dc,end="\n###########\n")
        entropies.append((get_entropy_of_dataset(dc),dc.shape[0]))
    #print(entropies)
    avg_info=0
    sizeattr=dfattr.shape[0]
    for ec in entropies:
        avg_info+=(ec[1] / sizeattr )* ec[0]
    # print(avg_info)
    return (avg_info)


'''Return Information Gain of the attribute provided as parameter'''
# input:pandas_dataframe,str
# output:int/float
def get_information_gain(df, attribute):

    entropy_dataset=get_entropy_of_dataset(df)
    entropy_attribute=get_avg_info_of_attribute(df,attribute)
    information_gain=entropy_dataset-entropy_attribute
    return information_gain

#input: pandas_dataframe
#output: ({dict},'str')
def get_selected_attribute(df):
    '''
    Return a tuple with the first element as a dictionary which has IG of all columns 
    and the second element as a string with the name of the column selected

    example : ({'A':0.123,'B':0.768,'C':1.23} , 'C')
    '''
    # information_gains=list()
    attributes=df.columns[:-1]
    solution = dict.fromkeys(attributes, 0)
    #print(attributes)
    for attribute in attributes:
        # information_gains.append(get_information_gain(df,attribute))
        solution[attribute]=get_information_gain(df,attribute)
    #print(solution)
    bestChoice = max(solution, key=solution.get)
    #print(bestChoice)
    return (solution,bestChoice)


##
outlook = 'overcast,overcast,overcast,overcast,rainy,rainy,rainy,rainy,rainy,sunny,sunny,sunny,sunny,sunny'.split(
    ',')
temp = 'hot,cool,mild,hot,mild,cool,cool,mild,mild,hot,hot,mild,cool,mild'.split(
    ',')
humidity = 'high,normal,high,normal,high,normal,normal,normal,high,high,high,high,normal,normal'.split(
    ',')
windy = 'FALSE,TRUE,TRUE,FALSE,FALSE,FALSE,TRUE,FALSE,TRUE,FALSE,TRUE,FALSE,FALSE,TRUE'.split(
    ',')
play = 'yes,yes,yes,yes,yes,yes,no,yes,no,no,no,no,yes,yes'.split(',')
dataset = {'outlook': outlook, 'temp': temp,
           'humidity': humidity, 'windy': windy, 'play': play}
df = pd.DataFrame(dataset, columns=[
                  'outlook', 'temp', 'humidity', 'windy', 'play'])

#print(get_entropy_of_dataset(df))
#print(get_avg_info_of_attribute(df,'temp'))
# print(get_avg_info_of_attribute(df,'outlook'))
# print(get_information_gain(df,'temp'))
# print(get_information_gain(df,'outlook'))
# print(get_selected_attribute(df))
