import tensorflow as tf
from week5 import *
import numpy as np

at = tf.Variable(tf.constant([[3.0,5.0], [7.0,4.0]]), name='at')
bt = tf.Variable(tf.constant([[8.0,4.0], [4.0,9.0]]), name='bt')
ct = tf.Variable(tf.constant([[5.2, 8.5], [6.8, 4.9]]), name='ct')

a = np.array(at)
b = np.array(bt)
c = np.array(ct)
al = Tensor(a)
bl = Tensor(b)
cl = Tensor(c)

at3 = tf.Variable(tf.constant([[3.0,5.0, 8.6], [7.0,4.0, 7.8], [3.3, 5.6, 7.6]]), name='at3')
bt3 = tf.Variable(tf.constant([[8.0,4.0, 7.3], [4.0,9.0, 9.8], [4.4, 5.6, 2.3]]), name='bt3')
ct3 = tf.Variable(tf.constant([[5.2,8.5, 6.4], [6.8, 4.9, 9.3],[5.7, 3.5, 9.2]]), name='ct3')
dt3 = tf.Variable(tf.constant([[2.2,2.5, 2.4], [3.8, 4.9, 8.3],[9.7, 7.5, 9.2]]), name='dt3')

a3 = np.array(at3)
b3 = np.array(bt3)
c3 = np.array(ct3)
d3 = np.array(dt3)
al3 = Tensor(a3)
bl3 = Tensor(b3)
cl3 = Tensor(c3)
dl3 = Tensor(d3)



'''Testcase1'''
testcase1 = al @ bl @ cl

testcase1.backward()
with tf.GradientTape() as tape:
  y = at @ bt @ ct

grad = tape.gradient(y, [at, bt, ct])
print("_____________________")
print("TestCase1")
print("_____________________")
print("Tensorflow Output\n")
print('\n\n'.join(map(lambda x:str(np.array(x)), grad)))
print("----------------------")
print("Your Output\n")
print('\n\n'.join(map(lambda x:str(x), [al.grad, bl.grad, cl.grad])))
print("_____________________")
al.zero_grad()
bl.zero_grad()
cl.zero_grad()

'''Testcase2'''
testcase2 = al + bl + cl
testcase2.backward()
with tf.GradientTape() as tape:
  y = at + bt + ct

grad = tape.gradient(y, [at, bt, ct])

print("TestCase2")
print("_____________________")
print("Tensorflow Output\n")
print('\n\n'.join(map(lambda x:str(np.array(x)), grad)))
print("----------------------")
print("Your Output\n")
print('\n\n'.join(map(lambda x:str(x), [al.grad, bl.grad, cl.grad])))
print("_____________________")
al.zero_grad()
bl.zero_grad()
cl.zero_grad()

'''Testcase3'''
testcase3 = (al @ cl) + bl
testcase3.backward()
with tf.GradientTape() as tape:
  y = (at @ ct) + bt

grad = tape.gradient(y, [at, bt, ct])

print("TestCase3")
print("_____________________")
print("Tensorflow Output\n")
print('\n\n'.join(map(lambda x:str(np.array(x)), grad)))
print("----------------------")
print("Your Output\n")
print('\n\n'.join(map(lambda x:str(x), [al.grad, bl.grad, cl.grad])))
print("_____________________")
al.zero_grad()
bl.zero_grad()
cl.zero_grad()
'''Testcase4'''
testcase4 = ((al @ cl) + (bl @ al)) @ cl
testcase4.backward()
with tf.GradientTape() as tape:
  y = ((at @ ct) + (bt @ at)) @ ct

grad = tape.gradient(y, [at, bt, ct])

print("TestCase4")
print("_____________________")
print("Tensorflow Output\n")
print('\n\n'.join(map(lambda x:str(np.array(x)), grad)))
print("----------------------")
print("Your Output\n")
print('\n\n'.join(map(lambda x:str(x), [al.grad, bl.grad, cl.grad])))
print("_____________________")
al.zero_grad()
bl.zero_grad()
cl.zero_grad()
'''Testcase5'''
testcase5 = (al3 @ bl3) + (cl3 @ dl3)
testcase5.backward()
with tf.GradientTape() as tape:
  y = (at3 @ bt3) + (ct3 @ dt3)

grad = tape.gradient(y, [at3, bt3, ct3, dt3])

print("TestCase5")
print("_____________________")
print("Tensorflow Output\n")
print('\n\n'.join(map(lambda x:str(np.array(x)), grad)))
print("----------------------")
print("Your Output\n")
print('\n\n'.join(map(lambda x:str(x), [al3.grad, bl3.grad, cl3.grad, dl3.grad])))
print("_____________________")
al.zero_grad()
bl.zero_grad()
cl.zero_grad()